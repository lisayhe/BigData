#!/bin/bash

python q2.py ${SGE_TASK_ID}