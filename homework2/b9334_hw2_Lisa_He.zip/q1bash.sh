#!/bin/bash

python q1.py ${SGE_TASK_ID}